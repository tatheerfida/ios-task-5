//
//  ViewController.swift
//  signup
//
//  Created by Harris Butt on 8/19/19.
//  Copyright © 2019 tatheer fida. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    
    @IBAction func login(_ sender: Any) {
        
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    @IBAction func back(_ sender: Any) {
    }
}

